package com.sriyank.typexaudio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button mButt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButt1=(Button)findViewById(R.id.playing_butt1);

        mButt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openPlayerActivity=new Intent(getApplicationContext(),PlayerActivity.class);
                startActivity(openPlayerActivity);
            }
        });//end of mButt1.setOnClick..

    }//end of onCreate..

}//end of MainActivity..
